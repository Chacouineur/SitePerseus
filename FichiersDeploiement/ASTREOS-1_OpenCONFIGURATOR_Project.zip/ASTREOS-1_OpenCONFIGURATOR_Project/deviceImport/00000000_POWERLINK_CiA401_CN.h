//Created by openPOWERLINK object dictionary creator V1.0.1 on 2023-12-15T23:25:07.052+01:00
/*
	vendorName: Unknown vendor
	vendorID: 0x00000000
	productName: openPOWERLINK device
	version: HW 1.00
	version: SW 1.00
	version: FW OPLK V2.7.0
*/

#define OBD_DEFINE_MACRO
	#include <obdcreate/obdmacro.h>
#undef OBD_DEFINE_MACRO

OBD_BEGIN()

	OBD_BEGIN_PART_GENERIC ()

		OBD_BEGIN_INDEX_RAM(0x1000, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1000, 0x00, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, NMT_DeviceType_U32, 0x000F0191)
		OBD_END_INDEX(0x1000)

		OBD_BEGIN_INDEX_RAM(0x1001, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1001, 0x00, kObdTypeUInt8, kObdAccR, tObdUnsigned8, ERR_ErrorRegister_U8, 0)
		OBD_END_INDEX(0x1001)

		OBD_BEGIN_INDEX_RAM(0x1006, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1006, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_CycleLen_U32, 1000)
		OBD_END_INDEX(0x1006)

		OBD_BEGIN_INDEX_RAM(0x1008, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VSTRING(0x1008, 0x00, kObdAccConst, NMT_ManufactDevName_VS, OBD_MAX_STRING_SIZE, "openPOWERLINK device")
		OBD_END_INDEX(0x1008)

		OBD_BEGIN_INDEX_RAM(0x1009, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VSTRING(0x1009, 0x00, kObdAccConst, NMT_ManufactHwVers_VS, OBD_MAX_STRING_SIZE, "1.00")
		OBD_END_INDEX(0x1009)

		OBD_BEGIN_INDEX_RAM(0x100A, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VSTRING(0x100A, 0x00, kObdAccConst, NMT_ManufactSwVers_VS, OBD_MAX_STRING_SIZE, "OPLK V2.7.0")
		OBD_END_INDEX(0x100A)

		OBD_BEGIN_INDEX_RAM(0x1010, 0x05, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1010, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 4)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1010, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, AllParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1010, 0x02, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CommunicationParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1010, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ApplicationParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1010, 0x04, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ManufacturerParam_04h_U32)
		OBD_END_INDEX(0x1010)

		OBD_BEGIN_INDEX_RAM(0x1011, 0x05, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1011, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 4)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1011, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, AllParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1011, 0x02, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CommunicationParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1011, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ApplicationParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1011, 0x04, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ManufacturerParam_04h_U32)
		OBD_END_INDEX(0x1011)

		OBD_BEGIN_INDEX_RAM(0x1018, 0x05, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1018, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 4)
			OBD_SUBINDEX_RAM_VAR(0x1018, 0x01, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, VendorId_U32, 0x00000000)
			OBD_SUBINDEX_RAM_VAR(0x1018, 0x02, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, ProductCode_U32, 0x00000000)
			OBD_SUBINDEX_RAM_VAR(0x1018, 0x03, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, RevisionNo_U32, 0x00020007)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1018, 0x04, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, SerialNo_U32)
		OBD_END_INDEX(0x1018)

		OBD_BEGIN_INDEX_RAM(0x1020, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1020, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR(0x1020, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ConfDate_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1020, 0x02, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ConfTime_U32, 0)
		OBD_END_INDEX(0x1020)

		OBD_BEGIN_INDEX_RAM(0x1030, 0x0A, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 9)
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x01, kObdTypeUInt16, kObdAccR, tObdUnsigned16, InterfaceIndex_U16, 1)
			OBD_SUBINDEX_RAM_VSTRING(0x1030, 0x02, kObdAccConst, InterfaceDescription_VSTR, OBD_MAX_STRING_SIZE, "Interface 1")
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x03, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, InterfaceType_U8, 6)
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x04, kObdTypeUInt16, kObdAccConst, tObdUnsigned16, InterfaceMtu_U16, 1518)
			OBD_SUBINDEX_RAM_OSTRING(0x1030, 0x05, kObdAccConst, InterfacePhysAddress_OSTR, OBD_MAX_STRING_SIZE)
			OBD_SUBINDEX_RAM_VSTRING(0x1030, 0x06, kObdAccR, InterfaceName_VSTR, OBD_MAX_STRING_SIZE, "Interface 1")
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x07, kObdTypeUInt8, kObdAccR, tObdUnsigned8, InterfaceOperStatus_U8, 1)
			OBD_SUBINDEX_RAM_VAR_RG(0x1030, 0x08, kObdTypeUInt8, kObdAccGRW, tObdUnsigned8, InterfaceAdminState_U8, 1, 0, 1)
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x09, kObdTypeBool, kObdAccRW, tObdBoolean, Valid_BOOL, true)
		OBD_END_INDEX(0x1030)

		OBD_RAM_INDEX_RAM_ARRAY(0x1050, 0xFE, FALSE, kObdTypeUInt32, kObdAccR, tObdUnsigned32, NMT_RelativeLatencyDiff_AU32, 0)

		OBD_BEGIN_INDEX_RAM(0x1300, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR_RG(0x1300, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, SDO_SequLayerTimeout_U32, 15000, 100)
		OBD_END_INDEX(0x1300)

		OBD_BEGIN_INDEX_RAM(0x1400, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1400, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1400, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1400, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1400)

		OBD_BEGIN_INDEX_RAM(0x1401, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1401, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1401, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1401, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1401)

		OBD_BEGIN_INDEX_RAM(0x1402, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1402, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1402, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1402, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1402)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1600, 0x19, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_00h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1601, 0x19, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_01h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1602, 0x19, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_02h_AU64, 0x0000000000000000LL)

		OBD_BEGIN_INDEX_RAM(0x1800, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1800, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1800, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1800, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1800)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A00, 0x19, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_00h_AU64, 0x0000000000000000LL)

		OBD_BEGIN_INDEX_RAM(0x1C0B, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C0B, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1C0B, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CumulativeCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0B, 0x02, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ThresholdCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0B, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, Threshold_U32, 15)
		OBD_END_INDEX(0x1C0B)

		OBD_BEGIN_INDEX_RAM(0x1C0D, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C0D, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1C0D, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CumulativeCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0D, 0x02, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ThresholdCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0D, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, Threshold_U32, 15)
		OBD_END_INDEX(0x1C0D)

		OBD_BEGIN_INDEX_RAM(0x1C0F, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C0F, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1C0F, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CumulativeCnt_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1C0F, 0x02, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ThresholdCnt_U32)
			OBD_SUBINDEX_RAM_VAR(0x1C0F, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, Threshold_U32, 15)
		OBD_END_INDEX(0x1C0F)

		OBD_BEGIN_INDEX_RAM(0x1C14, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C14, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, DLL_CNLossOfSocTolerance_U32, 100000)
		OBD_END_INDEX(0x1C14)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F81, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_NodeAssignment_AU32, 0)

		OBD_BEGIN_INDEX_RAM(0x1F82, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F82, 0x00, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, NMT_FeatureFlags_U32, 0x00058265)
		OBD_END_INDEX(0x1F82)

		OBD_BEGIN_INDEX_RAM(0x1F83, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F83, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NMT_EPLVersion_U8, 0x20)
		OBD_END_INDEX(0x1F83)

		OBD_BEGIN_INDEX_RAM(0x1F8C, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1F8C, 0x00, kObdTypeUInt8, kObdAccR, tObdUnsigned8, NMT_CurrNMTState_U8)
		OBD_END_INDEX(0x1F8C)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F8D, 0xFE, FALSE, kObdTypeUInt16, kObdAccRW, tObdUnsigned16, NMT_PResPayloadLimitList_AU16, 36)

		OBD_BEGIN_INDEX_RAM(0x1F93, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F93, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1F93, 0x01, kObdTypeUInt8, kObdAccR, tObdUnsigned8, NodeID_U8)
			OBD_SUBINDEX_RAM_VAR(0x1F93, 0x02, kObdTypeBool, kObdAccR, tObdBoolean, NodeIDByHW_BOOL, true)
		OBD_END_INDEX(0x1F93)

		OBD_BEGIN_INDEX_RAM(0x1F98, 0x0F, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 14)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x01, kObdTypeUInt16, kObdAccConst, tObdUnsigned16, IsochrTxMaxPayload_U16, 1490)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x02, kObdTypeUInt16, kObdAccConst, tObdUnsigned16, IsochrRxMaxPayload_U16, 1490)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x03, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, PResMaxLatency_U32, 2000)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x04, kObdTypeUInt16, kObdAccGRW, tObdUnsigned16, PReqActPayloadLimit_U16, 36, 36, 1490)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x05, kObdTypeUInt16, kObdAccGRW, tObdUnsigned16, PResActPayloadLimit_U16, 36, 36, 1490)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x06, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, ASndMaxLatency_U32, 2000)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x07, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MultiplCycleCnt_U8, 0)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x08, kObdTypeUInt16, kObdAccGRW, tObdUnsigned16, AsyncMTU_U16, 300, 300, 1500)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x09, kObdTypeUInt16, kObdAccGRW, tObdUnsigned16, Prescaler_U16, 2, 0, 1000)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x0A, kObdTypeUInt8, kObdAccR, tObdUnsigned8, PResMode_U8, 0, 1)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x0B, kObdTypeUInt32, kObdAccR, tObdUnsigned32, PResTimeFirst_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x0C, kObdTypeUInt32, kObdAccR, tObdUnsigned32, PResTimeSecond_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x0D, kObdTypeUInt32, kObdAccR, tObdUnsigned32, SyncMNDelayFirst_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x0E, kObdTypeUInt32, kObdAccR, tObdUnsigned32, SyncMNDelaySecond_U32, 0)
		OBD_END_INDEX(0x1F98)

		OBD_BEGIN_INDEX_RAM(0x1F99, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F99, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_CNBasicEthernetTimeout_U32, 5000000)
		OBD_END_INDEX(0x1F99)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F9B, 0xFE, FALSE, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NMT_MultiplCycleAssign_AU8, 0)

		OBD_BEGIN_INDEX_RAM(0x1F9E, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F9E, 0x00, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NMT_ResetCmd_U8, 255)
		OBD_END_INDEX(0x1F9E)

	OBD_END_PART()

	OBD_BEGIN_PART_MANUFACTURER ()

	OBD_END_PART()

	OBD_BEGIN_PART_DEVICE ()

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6000, 0x04, FALSE, kObdTypeUInt8, kObdAccPR, tObdUnsigned8, DigitalInput_00h_AU8)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6200, 0x04, FALSE, kObdTypeUInt8, kObdAccPRW, tObdUnsigned8, DigitalOutput_00h_AU8)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6400, 0x04, FALSE, kObdTypeInt8, kObdAccPR, tObdInteger8, AnalogueInput_00h_AI8)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6401, 0x02, FALSE, kObdTypeInt16, kObdAccPR, tObdInteger16, AnalogueInput_00h_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6402, 0x01, FALSE, kObdTypeInt32, kObdAccPR, tObdInteger32, AnalogueInput_00h_AI32)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6410, 0x04, FALSE, kObdTypeInt8, kObdAccPRW, tObdInteger8, AnalogueOutput_00h_AI8)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6411, 0x02, FALSE, kObdTypeInt16, kObdAccPRW, tObdInteger16, AnalogueOutput_00h_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6412, 0x01, FALSE, kObdTypeInt32, kObdAccPRW, tObdInteger32, AnalogueOutput_00h_AI32)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6500, 0xC, FALSE, kObdTypeInt8, kObdAccPR, tObdInteger16, VALVE_In_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6501, 0xF0, FALSE, kObdTypeInt16, kObdAccPR, tObdInteger16, EC_In_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6502, 0xC, FALSE, kObdTypeInt32, kObdAccPR, tObdInteger16, SENSOR_In_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6510, 0xC, FALSE, kObdTypeInt8, kObdAccPRW, tObdInteger16, VALVE_Out_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6511, 0xF0, FALSE, kObdTypeInt16, kObdAccPRW, tObdInteger16, EC_Out_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6512, 0xC, FALSE, kObdTypeInt32, kObdAccPRW, tObdInteger16, SENSOR_Out_AI16)

	OBD_END_PART()

OBD_END()

#define OBD_UNDEFINE_MACRO
	#include <obdcreate/obdmacro.h>
#undef OBD_UNDEFINE_MACRO
