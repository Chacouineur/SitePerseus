//Created by openPOWERLINK object dictionary creator V1.0.1 on 2023-12-15T23:24:46.047+01:00
/*
	vendorName: Unknown vendor
	vendorID: 0x00000000
	productName: openPOWERLINK device
	version: HW 1.00
	version: SW 1.00
	version: FW OPLK V2.7.0
*/

#define OBD_DEFINE_MACRO
	#include <obdcreate/obdmacro.h>
#undef OBD_DEFINE_MACRO

OBD_BEGIN()

	OBD_BEGIN_PART_GENERIC ()

		OBD_BEGIN_INDEX_RAM(0x1000, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1000, 0x00, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, NMT_DeviceType_U32, 0x00000000)
		OBD_END_INDEX(0x1000)

		OBD_BEGIN_INDEX_RAM(0x1001, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1001, 0x00, kObdTypeUInt8, kObdAccR, tObdUnsigned8, ERR_ErrorRegister_U8, 0)
		OBD_END_INDEX(0x1001)

		OBD_BEGIN_INDEX_RAM(0x1006, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1006, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_CycleLen_U32)
		OBD_END_INDEX(0x1006)

		OBD_BEGIN_INDEX_RAM(0x1008, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VSTRING(0x1008, 0x00, kObdAccConst, NMT_ManufactDevName_VS, OBD_MAX_STRING_SIZE, "openPOWERLINK device")
		OBD_END_INDEX(0x1008)

		OBD_BEGIN_INDEX_RAM(0x1009, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VSTRING(0x1009, 0x00, kObdAccConst, NMT_ManufactHwVers_VS, OBD_MAX_STRING_SIZE, "1.00")
		OBD_END_INDEX(0x1009)

		OBD_BEGIN_INDEX_RAM(0x100A, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VSTRING(0x100A, 0x00, kObdAccConst, NMT_ManufactSwVers_VS, OBD_MAX_STRING_SIZE, "OPLK V2.7.0")
		OBD_END_INDEX(0x100A)

		OBD_BEGIN_INDEX_RAM(0x1010, 0x05, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1010, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 4)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1010, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, AllParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1010, 0x02, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CommunicationParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1010, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ApplicationParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1010, 0x04, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ManufacturerParam_04h_U32)
		OBD_END_INDEX(0x1010)

		OBD_BEGIN_INDEX_RAM(0x1011, 0x05, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1011, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 4)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1011, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, AllParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1011, 0x02, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CommunicationParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1011, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ApplicationParam_U32)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1011, 0x04, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ManufacturerParam_04h_U32)
		OBD_END_INDEX(0x1011)

		OBD_BEGIN_INDEX_RAM(0x1018, 0x05, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1018, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 4)
			OBD_SUBINDEX_RAM_VAR(0x1018, 0x01, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, VendorId_U32, 0x00000000)
			OBD_SUBINDEX_RAM_VAR(0x1018, 0x02, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, ProductCode_U32, 0x00000000)
			OBD_SUBINDEX_RAM_VAR(0x1018, 0x03, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, RevisionNo_U32, 0x00020007)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1018, 0x04, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, SerialNo_U32)
		OBD_END_INDEX(0x1018)

		OBD_BEGIN_INDEX_RAM(0x1020, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1020, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR(0x1020, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ConfDate_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1020, 0x02, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, ConfTime_U32, 0)
		OBD_END_INDEX(0x1020)

		OBD_BEGIN_INDEX_RAM(0x1030, 0x0A, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 9)
			OBD_SUBINDEX_RAM_VAR_RG(0x1030, 0x01, kObdTypeUInt16, kObdAccGR, tObdUnsigned16, InterfaceIndex_U16, 1, 1, 10)
			OBD_SUBINDEX_RAM_VSTRING(0x1030, 0x02, kObdAccConst, InterfaceDescription_VSTR, OBD_MAX_STRING_SIZE, "Interface 1")
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x03, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, InterfaceType_U8, 6)
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x04, kObdTypeUInt16, kObdAccConst, tObdUnsigned16, InterfaceMtu_U16, 1518)
			OBD_SUBINDEX_RAM_OSTRING(0x1030, 0x05, kObdAccConst, InterfacePhysAddress_OSTR, OBD_MAX_STRING_SIZE)
			OBD_SUBINDEX_RAM_VSTRING(0x1030, 0x06, kObdAccR, InterfaceName_VSTR, OBD_MAX_STRING_SIZE, "Interface 1")
			OBD_SUBINDEX_RAM_VAR_RG(0x1030, 0x07, kObdTypeUInt8, kObdAccGR, tObdUnsigned8, InterfaceOperStatus_U8, 1, 0, 1)
			OBD_SUBINDEX_RAM_VAR_RG(0x1030, 0x08, kObdTypeUInt8, kObdAccGRW, tObdUnsigned8, InterfaceAdminState_U8, 1, 0, 1)
			OBD_SUBINDEX_RAM_VAR(0x1030, 0x09, kObdTypeBool, kObdAccRW, tObdBoolean, Valid_BOOL, true)
		OBD_END_INDEX(0x1030)

		OBD_RAM_INDEX_RAM_ARRAY(0x1050, 0xFE, FALSE, kObdTypeUInt32, kObdAccR, tObdUnsigned32, NMT_RelativeLatencyDiff_AU32, 0)

		OBD_BEGIN_INDEX_RAM(0x1300, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR_RG(0x1300, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, SDO_SequLayerTimeout_U32, 15000, 100)
		OBD_END_INDEX(0x1300)

		OBD_BEGIN_INDEX_RAM(0x1400, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1400, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1400, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1400, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1400)

		OBD_BEGIN_INDEX_RAM(0x1401, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1401, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1401, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1401, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1401)

		OBD_BEGIN_INDEX_RAM(0x1402, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1402, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1402, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1402, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1402)

		OBD_BEGIN_INDEX_RAM(0x1403, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1403, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1403, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1403, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1403)

		OBD_BEGIN_INDEX_RAM(0x1404, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1404, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1404, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1404, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1404)

		OBD_BEGIN_INDEX_RAM(0x1405, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1405, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1405, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1405, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1405)

		OBD_BEGIN_INDEX_RAM(0x1406, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1406, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1406, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1406, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1406)

		OBD_BEGIN_INDEX_RAM(0x1407, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1407, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1407, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1407, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1407)

		OBD_BEGIN_INDEX_RAM(0x1408, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1408, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1408, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1408, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1408)

		OBD_BEGIN_INDEX_RAM(0x1409, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1409, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1409, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1409, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1409)

		OBD_BEGIN_INDEX_RAM(0x140A, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x140A, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x140A, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x140A, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x140A)

		OBD_BEGIN_INDEX_RAM(0x140B, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x140B, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x140B, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x140B, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x140B)

		OBD_BEGIN_INDEX_RAM(0x140C, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x140C, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x140C, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x140C, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x140C)

		OBD_BEGIN_INDEX_RAM(0x140D, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x140D, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x140D, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x140D, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x140D)

		OBD_BEGIN_INDEX_RAM(0x140E, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x140E, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x140E, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x140E, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x140E)

		OBD_BEGIN_INDEX_RAM(0x140F, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x140F, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x140F, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x140F, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x140F)

		OBD_BEGIN_INDEX_RAM(0x1410, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1410, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1410, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1410, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1410)

		OBD_BEGIN_INDEX_RAM(0x1411, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1411, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1411, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1411, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1411)

		OBD_BEGIN_INDEX_RAM(0x1412, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1412, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1412, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1412, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1412)

		OBD_BEGIN_INDEX_RAM(0x1413, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1413, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1413, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1413, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1413)

		OBD_BEGIN_INDEX_RAM(0x1414, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1414, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1414, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1414, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1414)

		OBD_BEGIN_INDEX_RAM(0x1415, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1415, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1415, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1415, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1415)

		OBD_BEGIN_INDEX_RAM(0x1416, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1416, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1416, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1416, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1416)

		OBD_BEGIN_INDEX_RAM(0x1417, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1417, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1417, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1417, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1417)

		OBD_BEGIN_INDEX_RAM(0x1418, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1418, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1418, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1418, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1418)

		OBD_BEGIN_INDEX_RAM(0x1419, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1419, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1419, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1419, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1419)

		OBD_BEGIN_INDEX_RAM(0x141A, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x141A, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x141A, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x141A, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x141A)

		OBD_BEGIN_INDEX_RAM(0x141B, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x141B, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x141B, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x141B, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x141B)

		OBD_BEGIN_INDEX_RAM(0x141C, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x141C, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x141C, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x141C, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x141C)

		OBD_BEGIN_INDEX_RAM(0x141D, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x141D, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x141D, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x141D, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x141D)

		OBD_BEGIN_INDEX_RAM(0x141E, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x141E, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x141E, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x141E, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x141E)

		OBD_BEGIN_INDEX_RAM(0x141F, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x141F, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x141F, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x141F, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x141F)

		OBD_BEGIN_INDEX_RAM(0x1420, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1420, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1420, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1420, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1420)

		OBD_BEGIN_INDEX_RAM(0x1421, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1421, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1421, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1421, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1421)

		OBD_BEGIN_INDEX_RAM(0x1422, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1422, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1422, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1422, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1422)

		OBD_BEGIN_INDEX_RAM(0x1423, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1423, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1423, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1423, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1423)

		OBD_BEGIN_INDEX_RAM(0x1424, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1424, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1424, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1424, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1424)

		OBD_BEGIN_INDEX_RAM(0x1425, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1425, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1425, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1425, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1425)

		OBD_BEGIN_INDEX_RAM(0x1426, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1426, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1426, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1426, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1426)

		OBD_BEGIN_INDEX_RAM(0x1427, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1427, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1427, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1427, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1427)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1600, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_00h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1601, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_01h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1602, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_02h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1603, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_03h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1604, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_04h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1605, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_05h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1606, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_06h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1607, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_07h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1608, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_08h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1609, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_09h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x160A, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_0Ah_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x160B, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_0Bh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x160C, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_0Ch_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x160D, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_0Dh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x160E, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_0Eh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x160F, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_0Fh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1610, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_10h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1611, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_11h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1612, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_12h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1613, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_13h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1614, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_14h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1615, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_15h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1616, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_16h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1617, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_17h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1618, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_18h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1619, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_19h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x161A, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_1Ah_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x161B, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_1Bh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x161C, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_1Ch_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x161D, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_1Dh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x161E, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_1Eh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x161F, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_1Fh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1620, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_20h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1621, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_21h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1622, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_22h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1623, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_23h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1624, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_24h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1625, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_25h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1626, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_26h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1627, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_RxMappParam_27h_AU64, 0x0000000000000000LL)

		OBD_BEGIN_INDEX_RAM(0x1800, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1800, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1800, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1800, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1800)

		OBD_BEGIN_INDEX_RAM(0x1801, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1801, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1801, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1801, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1801)

		OBD_BEGIN_INDEX_RAM(0x1802, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1802, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1802, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1802, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1802)

		OBD_BEGIN_INDEX_RAM(0x1803, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1803, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1803, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1803, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1803)

		OBD_BEGIN_INDEX_RAM(0x1804, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1804, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1804, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1804, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1804)

		OBD_BEGIN_INDEX_RAM(0x1805, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1805, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1805, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1805, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1805)

		OBD_BEGIN_INDEX_RAM(0x1806, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1806, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1806, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1806, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1806)

		OBD_BEGIN_INDEX_RAM(0x1807, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1807, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1807, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1807, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1807)

		OBD_BEGIN_INDEX_RAM(0x1808, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1808, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1808, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1808, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1808)

		OBD_BEGIN_INDEX_RAM(0x1809, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1809, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1809, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1809, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1809)

		OBD_BEGIN_INDEX_RAM(0x180A, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x180A, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x180A, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x180A, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x180A)

		OBD_BEGIN_INDEX_RAM(0x180B, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x180B, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x180B, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x180B, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x180B)

		OBD_BEGIN_INDEX_RAM(0x180C, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x180C, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x180C, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x180C, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x180C)

		OBD_BEGIN_INDEX_RAM(0x180D, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x180D, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x180D, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x180D, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x180D)

		OBD_BEGIN_INDEX_RAM(0x180E, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x180E, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x180E, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x180E, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x180E)

		OBD_BEGIN_INDEX_RAM(0x180F, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x180F, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x180F, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x180F, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x180F)

		OBD_BEGIN_INDEX_RAM(0x1810, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1810, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1810, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1810, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1810)

		OBD_BEGIN_INDEX_RAM(0x1811, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1811, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1811, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1811, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1811)

		OBD_BEGIN_INDEX_RAM(0x1812, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1812, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1812, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1812, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1812)

		OBD_BEGIN_INDEX_RAM(0x1813, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1813, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1813, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1813, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1813)

		OBD_BEGIN_INDEX_RAM(0x1814, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1814, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1814, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1814, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1814)

		OBD_BEGIN_INDEX_RAM(0x1815, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1815, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1815, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1815, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1815)

		OBD_BEGIN_INDEX_RAM(0x1816, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1816, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1816, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1816, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1816)

		OBD_BEGIN_INDEX_RAM(0x1817, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1817, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1817, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1817, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1817)

		OBD_BEGIN_INDEX_RAM(0x1818, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1818, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1818, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1818, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1818)

		OBD_BEGIN_INDEX_RAM(0x1819, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1819, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1819, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1819, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1819)

		OBD_BEGIN_INDEX_RAM(0x181A, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x181A, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x181A, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x181A, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x181A)

		OBD_BEGIN_INDEX_RAM(0x181B, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x181B, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x181B, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x181B, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x181B)

		OBD_BEGIN_INDEX_RAM(0x181C, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x181C, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x181C, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x181C, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x181C)

		OBD_BEGIN_INDEX_RAM(0x181D, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x181D, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x181D, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x181D, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x181D)

		OBD_BEGIN_INDEX_RAM(0x181E, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x181E, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x181E, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x181E, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x181E)

		OBD_BEGIN_INDEX_RAM(0x181F, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x181F, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x181F, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x181F, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x181F)

		OBD_BEGIN_INDEX_RAM(0x1820, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1820, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1820, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1820, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1820)

		OBD_BEGIN_INDEX_RAM(0x1821, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1821, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1821, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1821, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1821)

		OBD_BEGIN_INDEX_RAM(0x1822, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1822, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1822, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1822, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1822)

		OBD_BEGIN_INDEX_RAM(0x1823, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1823, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1823, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1823, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1823)

		OBD_BEGIN_INDEX_RAM(0x1824, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1824, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1824, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1824, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1824)

		OBD_BEGIN_INDEX_RAM(0x1825, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1825, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1825, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1825, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1825)

		OBD_BEGIN_INDEX_RAM(0x1826, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1826, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1826, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1826, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1826)

		OBD_BEGIN_INDEX_RAM(0x1827, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1827, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_RG(0x1827, 0x01, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NodeID_U8, 0, 254)
			OBD_SUBINDEX_RAM_VAR(0x1827, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MappingVersion_U8, 0)
		OBD_END_INDEX(0x1827)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A00, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_00h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A01, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_01h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A02, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_02h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A03, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_03h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A04, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_04h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A05, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_05h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A06, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_06h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A07, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_07h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A08, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_08h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A09, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_09h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A0A, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_0Ah_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A0B, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_0Bh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A0C, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_0Ch_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A0D, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_0Dh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A0E, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_0Eh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A0F, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_0Fh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A10, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_10h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A11, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_11h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A12, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_12h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A13, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_13h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A14, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_14h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A15, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_15h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A16, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_16h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A17, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_17h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A18, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_18h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A19, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_19h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A1A, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_1Ah_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A1B, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_1Bh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A1C, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_1Ch_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A1D, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_1Dh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A1E, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_1Eh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A1F, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_1Fh_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A20, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_20h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A21, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_21h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A22, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_22h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A23, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_23h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A24, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_24h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A25, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_25h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A26, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_26h_AU64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_PDO_MAPPING(0x1A27, 0xFE, FALSE, kObdTypeUInt64, kObdAccRW, tObdUnsigned64, PDO_TxMappParam_27h_AU64, 0x0000000000000000LL)

		OBD_BEGIN_INDEX_RAM(0x1C00, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C00, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1C00, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CumulativeCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C00, 0x02, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ThresholdCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C00, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, Threshold_U32, 15)
		OBD_END_INDEX(0x1C00)

		OBD_BEGIN_INDEX_RAM(0x1C02, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C02, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1C02, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CumulativeCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C02, 0x02, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ThresholdCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C02, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, Threshold_U32, 15)
		OBD_END_INDEX(0x1C02)

		OBD_RAM_INDEX_RAM_ARRAY(0x1C07, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, DLL_MNCNLossPResCumCnt_AU32, 0)

		OBD_RAM_INDEX_RAM_ARRAY(0x1C08, 0xFE, FALSE, kObdTypeUInt32, kObdAccR, tObdUnsigned32, DLL_MNCNLossPResThrCnt_AU32, 0)

		OBD_RAM_INDEX_RAM_ARRAY(0x1C09, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, DLL_MNCNLossPResThreshold_AU32, 15)

		OBD_BEGIN_INDEX_RAM(0x1C0B, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C0B, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1C0B, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CumulativeCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0B, 0x02, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ThresholdCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0B, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, Threshold_U32, 15)
		OBD_END_INDEX(0x1C0B)

		OBD_BEGIN_INDEX_RAM(0x1C0D, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C0D, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1C0D, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CumulativeCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0D, 0x02, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ThresholdCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0D, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, Threshold_U32, 15)
		OBD_END_INDEX(0x1C0D)

		OBD_BEGIN_INDEX_RAM(0x1C0F, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C0F, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1C0F, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CumulativeCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0F, 0x02, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ThresholdCnt_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1C0F, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, Threshold_U32, 15)
		OBD_END_INDEX(0x1C0F)

		OBD_BEGIN_INDEX_RAM(0x1C12, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C12, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, DLL_MNCycleSuspendNumber_U32, 1)
		OBD_END_INDEX(0x1C12)

		OBD_BEGIN_INDEX_RAM(0x1C14, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1C14, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, DLL_CNLossOfSocTolerance_U32, 100000)
		OBD_END_INDEX(0x1C14)

		OBD_RAM_INDEX_RAM_ARRAY(0x1C16, 0xFE, FALSE, kObdTypeUInt32, kObdAccR, tObdUnsigned32, DLL_MNLossStatusResThrCnt_AU32, 0)

		OBD_RAM_INDEX_RAM_ARRAY(0x1C17, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, DLL_MNLossStatusResThreshold_AU32, 15)

		OBD_BEGIN_INDEX_RAM(0x1E40, 0x06, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1E40, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 5)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1E40, 0x01, kObdTypeUInt16, kObdAccR, tObdUnsigned16, IfIndex_U16)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1E40, 0x02, kObdTypeIP_Addr, kObdAccRW, tObd0402, Addr_IPAD)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1E40, 0x03, kObdTypeIP_Addr, kObdAccRW, tObd0402, NetMask_IPAD)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1E40, 0x04, kObdTypeUInt16, kObdAccR, tObdUnsigned16, ReasmMaxSize_U16)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1E40, 0x05, kObdTypeIP_Addr, kObdAccRW, tObd0402, DefaultGateway_IPAD)
		OBD_END_INDEX(0x1E40)

		OBD_BEGIN_INDEX_RAM(0x1E4A, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1E4A, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1E4A, 0x01, kObdTypeBool, kObdAccRW, tObdBoolean, Forwarding_BOOL, false)
			OBD_SUBINDEX_RAM_VAR(0x1E4A, 0x02, kObdTypeUInt16, kObdAccRW, tObdUnsigned16, DefaultTTL_U16, 64)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1E4A, 0x03, kObdTypeUInt32, kObdAccR, tObdUnsigned32, ForwardDatagrams_U32)
		OBD_END_INDEX(0x1E4A)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F22, 0xFE, FALSE, kObdTypeDomain, kObdAccRW, tObdDomain, CFM_ConciseDcfList_ADOM)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F26, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CFM_ExpConfDateList_AU32, 0)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F27, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, CFM_ExpConfTimeList_AU32, 0)

		OBD_BEGIN_INDEX_RAM(0x1F80, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F80, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_StartUp_U32, 0x00000800)
		OBD_END_INDEX(0x1F80)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F81, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_NodeAssignment_AU32, 0)

		OBD_BEGIN_INDEX_RAM(0x1F82, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F82, 0x00, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, NMT_FeatureFlags_U32, 0x00048367)
		OBD_END_INDEX(0x1F82)

		OBD_BEGIN_INDEX_RAM(0x1F83, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F83, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NMT_EPLVersion_U8, 0x20)
		OBD_END_INDEX(0x1F83)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F84, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_MNDeviceTypeIdList_AU32, 0)

		OBD_BEGIN_INDEX_RAM(0x1F89, 0x06, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F89, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 5)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F89, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, MNWaitNotAct_U32, 1000000, 250)
			OBD_SUBINDEX_RAM_VAR(0x1F89, 0x02, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, MNTimeoutPreOp1_U32, 500000)
			OBD_SUBINDEX_RAM_VAR(0x1F89, 0x03, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, MNWaitPreOp1_U32, 500000)
			OBD_SUBINDEX_RAM_VAR(0x1F89, 0x04, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, MNTimeoutPreOp2_U32, 5000000)
			OBD_SUBINDEX_RAM_VAR(0x1F89, 0x05, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, MNTimeoutReadyToOp_U32, 500000)
		OBD_END_INDEX(0x1F89)

		OBD_BEGIN_INDEX_RAM(0x1F8A, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F8A, 0x00, kObdTypeUInt8, kObdAccR, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR(0x1F8A, 0x01, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, WaitSoCPReq_U32, 1000)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F8A, 0x02, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, AsyncSlotTimeout_U32, 100000, 250)
		OBD_END_INDEX(0x1F8A)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F8B, 0xFE, FALSE, kObdTypeUInt16, kObdAccGRW, tObdUnsigned16, NMT_MNPReqPayloadLimitList_AU16, 36)

		OBD_BEGIN_INDEX_RAM(0x1F8C, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1F8C, 0x00, kObdTypeUInt8, kObdAccR, tObdUnsigned8, NMT_CurrNMTState_U8)
		OBD_END_INDEX(0x1F8C)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F8D, 0xFE, FALSE, kObdTypeUInt16, kObdAccRW, tObdUnsigned16, NMT_PResPayloadLimitList_AU16, 36)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F8E, 0xFE, FALSE, kObdTypeUInt8, kObdAccR, tObdUnsigned8, NMT_MNNodeCurrState_AU8, 0x1C)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F8F, 0xFE, FALSE, kObdTypeUInt8, kObdAccR, tObdUnsigned8, NMT_MNNodeExpState_AU8, 0x1C)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F92, 0xFE, FALSE, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_MNCNPResTimeout_AU32, 25000)

		OBD_BEGIN_INDEX_RAM(0x1F93, 0x03, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F93, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 2)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1F93, 0x01, kObdTypeUInt8, kObdAccR, tObdUnsigned8, NodeID_U8)
			OBD_SUBINDEX_RAM_VAR_NOINIT(0x1F93, 0x02, kObdTypeBool, kObdAccR, tObdBoolean, NodeIDByHW_BOOL)
		OBD_END_INDEX(0x1F93)

		OBD_BEGIN_INDEX_RAM(0x1F98, 0x0F, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 14)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x01, kObdTypeUInt16, kObdAccGConst, tObdUnsigned16, IsochrTxMaxPayload_U16, 36, 1490)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x02, kObdTypeUInt16, kObdAccGConst, tObdUnsigned16, IsochrRxMaxPayload_U16, 36, 1490)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x03, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, PResMaxLatency_U32, 2000)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x04, kObdTypeUInt16, kObdAccGRW, tObdUnsigned16, PReqActPayloadLimit_U16, 36, 36, 1490)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x05, kObdTypeUInt16, kObdAccGRW, tObdUnsigned16, PResActPayloadLimit_U16, 36, 36, 1490)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x06, kObdTypeUInt32, kObdAccConst, tObdUnsigned32, ASndMaxLatency_U32, 2000)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x07, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, MultiplCycleCnt_U8, 0)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x08, kObdTypeUInt16, kObdAccGRW, tObdUnsigned16, AsyncMTU_U16, 300, 300, 1500)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x09, kObdTypeUInt16, kObdAccRW, tObdUnsigned16, Prescaler_U16, 2, 1000)
			OBD_SUBINDEX_RAM_VAR_RG(0x1F98, 0x0A, kObdTypeUInt8, kObdAccR, tObdUnsigned8, PResMode_U8, 0, 1)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x0B, kObdTypeUInt32, kObdAccR, tObdUnsigned32, PResTimeFirst_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x0C, kObdTypeUInt32, kObdAccR, tObdUnsigned32, PResTimeSecond_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x0D, kObdTypeUInt32, kObdAccR, tObdUnsigned32, SyncMNDelayFirst_U32, 0)
			OBD_SUBINDEX_RAM_VAR(0x1F98, 0x0E, kObdTypeUInt32, kObdAccR, tObdUnsigned32, SyncMNDelaySecond_U32, 0)
		OBD_END_INDEX(0x1F98)

		OBD_BEGIN_INDEX_RAM(0x1F99, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F99, 0x00, kObdTypeUInt32, kObdAccRW, tObdUnsigned32, NMT_CNBasicEthernetTimeout_U32, 5000000)
		OBD_END_INDEX(0x1F99)

		OBD_BEGIN_INDEX_RAM(0x1F9A, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VSTRING(0x1F9A, 0x00, kObdAccRW, NMT_HostName_VSTR, OBD_MAX_STRING_SIZE)
		OBD_END_INDEX(0x1F9A)

		OBD_RAM_INDEX_RAM_ARRAY(0x1F9B, 0xFE, FALSE, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NMT_MultiplCycleAssign_AU8, 0)

		OBD_BEGIN_INDEX_RAM(0x1F9E, 0x01, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F9E, 0x00, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, NMT_ResetCmd_U8, 0xFF)
		OBD_END_INDEX(0x1F9E)

		OBD_BEGIN_INDEX_RAM(0x1F9F, 0x04, FALSE)
			OBD_SUBINDEX_RAM_VAR(0x1F9F, 0x00, kObdTypeUInt8, kObdAccConst, tObdUnsigned8, NumberOfEntries, 3)
			OBD_SUBINDEX_RAM_VAR(0x1F9F, 0x01, kObdTypeBool, kObdAccRW, tObdBoolean, Release_BOOL, false)
			OBD_SUBINDEX_RAM_VAR(0x1F9F, 0x02, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, CmdID_U8, 255)
			OBD_SUBINDEX_RAM_VAR(0x1F9F, 0x03, kObdTypeUInt8, kObdAccRW, tObdUnsigned8, CmdTarget_U8, 0)
		OBD_END_INDEX(0x1F9F)

	OBD_END_PART()

	OBD_BEGIN_PART_MANUFACTURER ()

	OBD_END_PART()

	OBD_BEGIN_PART_DEVICE ()

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6000, 0x04, FALSE, kObdTypeUInt8, kObdAccPR, tObdUnsigned8, DigitalInput_00h_AU8)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6200, 0x04, FALSE, kObdTypeUInt8, kObdAccPRW, tObdUnsigned8, DigitalOutput_00h_AU8)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6400, 0x04, FALSE, kObdTypeInt8, kObdAccPR, tObdInteger8, AnalogueInput_00h_AI8)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6401, 0x02, FALSE, kObdTypeInt16, kObdAccPR, tObdInteger16, AnalogueInput_00h_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6402, 0x01, FALSE, kObdTypeInt32, kObdAccPR, tObdInteger32, AnalogueInput_00h_AI32)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6410, 0x04, FALSE, kObdTypeInt8, kObdAccPRW, tObdInteger8, AnalogueOutput_00h_AI8)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6411, 0x02, FALSE, kObdTypeInt16, kObdAccPRW, tObdInteger16, AnalogueOutput_00h_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6412, 0x01, FALSE, kObdTypeInt32, kObdAccPRW, tObdInteger32, AnalogueOutput_00h_AI32)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6500, 0xC, FALSE, kObdTypeInt8, kObdAccPR, tObdInteger16, VALVE_In_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6501, 0xF0, FALSE, kObdTypeInt16, kObdAccPR, tObdInteger16, EC_In_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6502, 0xC, FALSE, kObdTypeInt32, kObdAccPR, tObdInteger16, SENSOR_In_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6510, 0xC, FALSE, kObdTypeInt8, kObdAccPRW, tObdInteger16, VALVE_Out_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6511, 0xF0, FALSE, kObdTypeInt16, kObdAccPRW, tObdInteger16, EC_Out_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY_NOINIT(0x6512, 0xC, FALSE, kObdTypeInt32, kObdAccPRW, tObdInteger16, SENSOR_Out_AI16)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA000, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA001, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA002, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA003, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA004, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA005, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA006, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA007, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA008, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA009, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA00A, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA00B, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA00C, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA00D, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA00E, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA00F, (252), FALSE, kObdTypeInt8, kObdAccVPR, tObdInteger8, PI_INPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA040, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA041, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA042, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA043, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA044, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA045, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA046, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA047, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA048, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA049, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA04A, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA04B, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA04C, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA04D, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA04E, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA04F, (252), FALSE, kObdTypeUInt8, kObdAccVPR, tObdUnsigned8, PI_INPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA0C0, (252), FALSE, kObdTypeInt16, kObdAccVPR, tObdInteger16, PI_INPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA0C1, (252), FALSE, kObdTypeInt16, kObdAccVPR, tObdInteger16, PI_INPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA0C2, (252), FALSE, kObdTypeInt16, kObdAccVPR, tObdInteger16, PI_INPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA0C3, (252), FALSE, kObdTypeInt16, kObdAccVPR, tObdInteger16, PI_INPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA0C4, (252), FALSE, kObdTypeInt16, kObdAccVPR, tObdInteger16, PI_INPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA0C5, (252), FALSE, kObdTypeInt16, kObdAccVPR, tObdInteger16, PI_INPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA0C6, (252), FALSE, kObdTypeInt16, kObdAccVPR, tObdInteger16, PI_INPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA0C7, (252), FALSE, kObdTypeInt16, kObdAccVPR, tObdInteger16, PI_INPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA100, (252), FALSE, kObdTypeUInt16, kObdAccVPR, tObdUnsigned16, PI_INPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA101, (252), FALSE, kObdTypeUInt16, kObdAccVPR, tObdUnsigned16, PI_INPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA102, (252), FALSE, kObdTypeUInt16, kObdAccVPR, tObdUnsigned16, PI_INPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA103, (252), FALSE, kObdTypeUInt16, kObdAccVPR, tObdUnsigned16, PI_INPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA104, (252), FALSE, kObdTypeUInt16, kObdAccVPR, tObdUnsigned16, PI_INPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA105, (252), FALSE, kObdTypeUInt16, kObdAccVPR, tObdUnsigned16, PI_INPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA106, (252), FALSE, kObdTypeUInt16, kObdAccVPR, tObdUnsigned16, PI_INPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA107, (252), FALSE, kObdTypeUInt16, kObdAccVPR, tObdUnsigned16, PI_INPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA1C0, (252), FALSE, kObdTypeInt32, kObdAccVPR, tObdInteger32, PI_INPUT_I32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA1C1, (252), FALSE, kObdTypeInt32, kObdAccVPR, tObdInteger32, PI_INPUT_I32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA1C2, (252), FALSE, kObdTypeInt32, kObdAccVPR, tObdInteger32, PI_INPUT_I32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA1C3, (252), FALSE, kObdTypeInt32, kObdAccVPR, tObdInteger32, PI_INPUT_I32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA200, (252), FALSE, kObdTypeUInt32, kObdAccVPR, tObdUnsigned32, PI_INPUT_U32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA201, (252), FALSE, kObdTypeUInt32, kObdAccVPR, tObdUnsigned32, PI_INPUT_U32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA202, (252), FALSE, kObdTypeUInt32, kObdAccVPR, tObdUnsigned32, PI_INPUT_U32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA203, (252), FALSE, kObdTypeUInt32, kObdAccVPR, tObdUnsigned32, PI_INPUT_U32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA240, (252), FALSE, kObdTypeReal32, kObdAccVPR, tObdReal32, PI_INPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA241, (252), FALSE, kObdTypeReal32, kObdAccVPR, tObdReal32, PI_INPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA242, (252), FALSE, kObdTypeReal32, kObdAccVPR, tObdReal32, PI_INPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA243, (252), FALSE, kObdTypeReal32, kObdAccVPR, tObdReal32, PI_INPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA244, (252), FALSE, kObdTypeReal32, kObdAccVPR, tObdReal32, PI_INPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA245, (252), FALSE, kObdTypeReal32, kObdAccVPR, tObdReal32, PI_INPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA246, (252), FALSE, kObdTypeReal32, kObdAccVPR, tObdReal32, PI_INPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA247, (252), FALSE, kObdTypeReal32, kObdAccVPR, tObdReal32, PI_INPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA400, (252), FALSE, kObdTypeInt64, kObdAccVPR, tObdInteger64, PI_INPUT_I64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA401, (252), FALSE, kObdTypeInt64, kObdAccVPR, tObdInteger64, PI_INPUT_I64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA440, (252), FALSE, kObdTypeUInt64, kObdAccVPR, tObdUnsigned64, PI_INPUT_U64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA441, (252), FALSE, kObdTypeUInt64, kObdAccVPR, tObdUnsigned64, PI_INPUT_U64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA480, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA481, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA482, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA483, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA484, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA485, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA486, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA487, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA488, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA489, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA48A, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA48B, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA48C, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA48D, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA48E, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA48F, (252), FALSE, kObdTypeInt8, kObdAccVPRW, tObdInteger8, PI_OUTPUT_I8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C0, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C1, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C2, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C3, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C4, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C5, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C6, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C7, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C8, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4C9, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4CA, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4CB, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4CC, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4CD, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4CE, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA4CF, (252), FALSE, kObdTypeUInt8, kObdAccVPRW, tObdUnsigned8, PI_OUTPUT_U8, 0x00)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA540, (252), FALSE, kObdTypeInt16, kObdAccVPRW, tObdInteger16, PI_OUTPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA541, (252), FALSE, kObdTypeInt16, kObdAccVPRW, tObdInteger16, PI_OUTPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA542, (252), FALSE, kObdTypeInt16, kObdAccVPRW, tObdInteger16, PI_OUTPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA543, (252), FALSE, kObdTypeInt16, kObdAccVPRW, tObdInteger16, PI_OUTPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA544, (252), FALSE, kObdTypeInt16, kObdAccVPRW, tObdInteger16, PI_OUTPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA545, (252), FALSE, kObdTypeInt16, kObdAccVPRW, tObdInteger16, PI_OUTPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA546, (252), FALSE, kObdTypeInt16, kObdAccVPRW, tObdInteger16, PI_OUTPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA547, (252), FALSE, kObdTypeInt16, kObdAccVPRW, tObdInteger16, PI_OUTPUT_I16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA580, (252), FALSE, kObdTypeUInt16, kObdAccVPRW, tObdUnsigned16, PI_OUTPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA581, (252), FALSE, kObdTypeUInt16, kObdAccVPRW, tObdUnsigned16, PI_OUTPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA582, (252), FALSE, kObdTypeUInt16, kObdAccVPRW, tObdUnsigned16, PI_OUTPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA583, (252), FALSE, kObdTypeUInt16, kObdAccVPRW, tObdUnsigned16, PI_OUTPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA584, (252), FALSE, kObdTypeUInt16, kObdAccVPRW, tObdUnsigned16, PI_OUTPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA585, (252), FALSE, kObdTypeUInt16, kObdAccVPRW, tObdUnsigned16, PI_OUTPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA586, (252), FALSE, kObdTypeUInt16, kObdAccVPRW, tObdUnsigned16, PI_OUTPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA587, (252), FALSE, kObdTypeUInt16, kObdAccVPRW, tObdUnsigned16, PI_OUTPUT_U16, 0x0000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA640, (252), FALSE, kObdTypeInt32, kObdAccVPRW, tObdInteger32, PI_OUTPUT_I32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA641, (252), FALSE, kObdTypeInt32, kObdAccVPRW, tObdInteger32, PI_OUTPUT_I32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA642, (252), FALSE, kObdTypeInt32, kObdAccVPRW, tObdInteger32, PI_OUTPUT_I32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA643, (252), FALSE, kObdTypeInt32, kObdAccVPRW, tObdInteger32, PI_OUTPUT_I32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA680, (252), FALSE, kObdTypeUInt32, kObdAccVPRW, tObdUnsigned32, PI_OUTPUT_U32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA681, (252), FALSE, kObdTypeUInt32, kObdAccVPRW, tObdUnsigned32, PI_OUTPUT_U32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA682, (252), FALSE, kObdTypeUInt32, kObdAccVPRW, tObdUnsigned32, PI_OUTPUT_U32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA683, (252), FALSE, kObdTypeUInt32, kObdAccVPRW, tObdUnsigned32, PI_OUTPUT_U32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA6C0, (252), FALSE, kObdTypeReal32, kObdAccVPRW, tObdReal32, PI_OUTPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA6C1, (252), FALSE, kObdTypeReal32, kObdAccVPRW, tObdReal32, PI_OUTPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA6C2, (252), FALSE, kObdTypeReal32, kObdAccVPRW, tObdReal32, PI_OUTPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA6C3, (252), FALSE, kObdTypeReal32, kObdAccVPRW, tObdReal32, PI_OUTPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA6C4, (252), FALSE, kObdTypeReal32, kObdAccVPRW, tObdReal32, PI_OUTPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA6C5, (252), FALSE, kObdTypeReal32, kObdAccVPRW, tObdReal32, PI_OUTPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA6C6, (252), FALSE, kObdTypeReal32, kObdAccVPRW, tObdReal32, PI_OUTPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA6C7, (252), FALSE, kObdTypeReal32, kObdAccVPRW, tObdReal32, PI_OUTPUT_R32, 0x00000000)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA880, (252), FALSE, kObdTypeInt64, kObdAccVPRW, tObdInteger64, PI_OUTPUT_I64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA881, (252), FALSE, kObdTypeInt64, kObdAccVPRW, tObdInteger64, PI_OUTPUT_I64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA8C0, (252), FALSE, kObdTypeUInt64, kObdAccVPRW, tObdUnsigned64, PI_OUTPUT_U64, 0x0000000000000000LL)

		OBD_RAM_INDEX_RAM_VARARRAY(0xA8C1, (252), FALSE, kObdTypeUInt64, kObdAccVPRW, tObdUnsigned64, PI_OUTPUT_U64, 0x0000000000000000LL)

	OBD_END_PART()

OBD_END()

#define OBD_UNDEFINE_MACRO
	#include <obdcreate/obdmacro.h>
#undef OBD_UNDEFINE_MACRO
