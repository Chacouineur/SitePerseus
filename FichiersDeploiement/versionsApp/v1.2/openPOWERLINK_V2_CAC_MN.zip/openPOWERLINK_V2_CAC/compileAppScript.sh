#!/bin/bash

LOGFILE=~/logfile.log
exec > >(tee -a "$LOGFILE") 2>&1

# Source the user's profile to set up the environment
source ~/.profile

# Function to check the status of the last executed command and exit if it failed
check_status() {
    if [ $? -ne 0 ]; then
        exit 1
    fi
}

# Change to the specified directory
echo "Changing directory"
cd ~/openPOWERLINK_V2_CAC/ || exit 1
check_status

# Touch all files found
echo "Finding and touching files"
find . -type f | xargs touch | true

# Change to the build directory
echo "Changing to build directory"
cd apps/OBC_MN/build/linux/ || exit 1
check_status

# Run cmake with specified options
echo "Running cmake"
cmake -DCFG_BUILD_KERNEL_STACK="Link to Application" -DCFG_STORE_RESTORE=FALSE ../.. || exit 1
check_status

# Clean the build
echo "Running make clean"
make clean || exit 1
check_status

# Build the project
echo "Running make"
make || exit 1
check_status

# Install the build
echo "Running make install"
make install || exit 1
check_status

echo "Restart OBCProgram service"
sudo service OBCProgram restart
check_status

# Exit with status 0 if all commands succeeded
echo "Script completed"
exit 0
