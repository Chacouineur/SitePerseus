var searchData=
[
  ['fgsoff_5fl_0',['fGsOff_l',['../opl_8cpp.html#a8f25e48b0b5122c1580e0728bcba0244',1,'opl.cpp']]],
  ['fwinfofile_1',['fwInfoFile',['../structt_options.html#a32813633c4fc364b2354b34c93af6d5c',1,'tOptions']]]
];
