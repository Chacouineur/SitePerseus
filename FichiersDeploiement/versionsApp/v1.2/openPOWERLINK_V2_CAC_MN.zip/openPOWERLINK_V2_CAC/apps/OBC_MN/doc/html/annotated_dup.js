var annotated_dup =
[
    [ "dataActivation", "structdata_activation.html", null ],
    [ "dataEG", "structdata_e_g.html", null ],
    [ "file", "classfile.html", "classfile" ],
    [ "LigneActivation", "struct_ligne_activation.html", "struct_ligne_activation" ],
    [ "LigneEG", "struct_ligne_e_g.html", "struct_ligne_e_g" ],
    [ "opl", "classopl.html", "classopl" ],
    [ "PI_IN", "struct_p_i___i_n.html", "struct_p_i___i_n" ],
    [ "PI_OUT", "struct_p_i___o_u_t.html", "struct_p_i___o_u_t" ],
    [ "tDemoNodeInfo", "structt_demo_node_info.html", "structt_demo_node_info" ],
    [ "tEventConfig", "structt_event_config.html", "structt_event_config" ],
    [ "tEventInstance", "structt_event_instance.html", "structt_event_instance" ],
    [ "tOptions", "structt_options.html", "structt_options" ]
];