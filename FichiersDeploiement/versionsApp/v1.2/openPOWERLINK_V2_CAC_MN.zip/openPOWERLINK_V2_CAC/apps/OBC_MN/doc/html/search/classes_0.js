var searchData=
[
  ['dataactivation_0',['dataActivation',['../structdata_activation.html',1,'']]],
  ['dataeg_1',['dataEG',['../structdata_e_g.html',1,'']]]
];
