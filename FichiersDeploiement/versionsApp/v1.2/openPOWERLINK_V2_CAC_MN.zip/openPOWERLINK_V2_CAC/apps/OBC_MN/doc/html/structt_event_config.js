var structt_event_config =
[
    [ "pfGsOff", "structt_event_config.html#a5baa11deb2b8d39e42178a4a72100292", null ],
    [ "pfnFirmwareManagerCallback", "structt_event_config.html#a210224e651107b9afb21698ad40d9ad0", null ]
];