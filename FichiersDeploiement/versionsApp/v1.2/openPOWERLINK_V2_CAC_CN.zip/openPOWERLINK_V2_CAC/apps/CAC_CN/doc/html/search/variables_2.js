var searchData=
[
  ['ctx_0',['ctx',['../sensor_8cpp.html#abbcd977f5e414946647edf65cdeb74ce',1,'sensor.cpp']]],
  ['currenttime_1',['currentTime',['../valve_8cpp.html#a718c1d403150a0052fdc750073ecede8',1,'valve.cpp']]]
];
