var searchData=
[
  ['processerrorwarningevent_0',['processErrorWarningEvent',['../event_opl_8c.html#a471f0e4af307e5efc3d9e210cbd55bf3',1,'eventOpl.c']]],
  ['processevents_1',['processEvents',['../event_opl_8c.html#ad6f574bee28d3a8f66b5885f365a8df2',1,'processEvents(tOplkApiEventType eventType_p, const tOplkApiEventArg *pEventArg_p, void *pUserArg_p):&#160;eventOpl.c'],['../event_opl_8h.html#ad6f574bee28d3a8f66b5885f365a8df2',1,'processEvents(tOplkApiEventType eventType_p, const tOplkApiEventArg *pEventArg_p, void *pUserArg_p):&#160;eventOpl.c']]],
  ['processpdochangeevent_2',['processPdoChangeEvent',['../event_opl_8c.html#aa2cf6c59fdc9a28d59a00bc8787eec9d',1,'eventOpl.c']]],
  ['processstatechangeevent_3',['processStateChangeEvent',['../event_opl_8c.html#a0e1b53cf0cea4698362f22fa97c0ceb4',1,'eventOpl.c']]],
  ['processsync_4',['processSync',['../opl_8cpp.html#a52e9ad149905d67047d527f120a17c11',1,'processSync():&#160;opl.cpp'],['../opl_8h.html#ac86056da77ac48c34bffd6a85f4567fe',1,'processSync(void):&#160;opl.cpp']]]
];
