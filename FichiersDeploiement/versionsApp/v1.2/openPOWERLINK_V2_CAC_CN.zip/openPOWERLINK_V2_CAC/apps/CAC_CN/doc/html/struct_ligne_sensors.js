var struct_ligne_sensors =
[
    [ "modbusAddrRemoteSlave", "struct_ligne_sensors.html#a98e8c6864249a7484da384c913c9ea94", null ],
    [ "modbusBaudRate", "struct_ligne_sensors.html#ab61ec429882cffad92537793daa1c2ca", null ],
    [ "modbusDataBits", "struct_ligne_sensors.html#a0f1c20c298cf84a63083b359a872094c", null ],
    [ "modbusParity", "struct_ligne_sensors.html#ad0ee05deedbd75f69e8b5826d391347f", null ],
    [ "modbusStartAddress", "struct_ligne_sensors.html#adc8f6947ec48d80236cd6dcd3ac67549", null ],
    [ "modbusStopBit", "struct_ligne_sensors.html#a2f41df6d3b7bb2f8415a482948bd560e", null ],
    [ "type", "struct_ligne_sensors.html#acd08584fa26b33d7fe6a457b8acf6c1d", null ]
];