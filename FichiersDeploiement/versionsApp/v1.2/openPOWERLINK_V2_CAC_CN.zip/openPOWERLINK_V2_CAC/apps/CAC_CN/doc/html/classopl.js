var classopl =
[
    [ "opl", "classopl.html#a43a83ace00cba207a89cf65e3b995d7e", null ],
    [ "~opl", "classopl.html#a8d5d5db31b3d8150af42d2bb000d94fa", null ],
    [ "demandeExtinctOPL", "classopl.html#ac3e6c6fb9c8d2a10d4437877651167bb", null ],
    [ "sendError", "classopl.html#ad188b100fd92fcc210bd48ea4e08a36f", null ],
    [ "sendTelem", "classopl.html#afcb3f7b05602f12b72bc97404795ef42", null ]
];