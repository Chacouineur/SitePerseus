var struct_ligne_vannes =
[
    [ "etatInitial", "struct_ligne_vannes.html#a413b83e1e29442b6c79f508e70132b99", null ],
    [ "portGPIO", "struct_ligne_vannes.html#ab74f4156992a1d50dc08493868258282", null ]
];