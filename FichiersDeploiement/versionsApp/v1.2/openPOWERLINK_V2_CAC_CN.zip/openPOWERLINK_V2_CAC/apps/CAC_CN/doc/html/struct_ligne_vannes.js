var struct_ligne_vannes =
[
    [ "etatInitial", "struct_ligne_vannes.html#afc9c8286c2e0a17637b3e74b9a9b0b0c", null ],
    [ "portGPIO", "struct_ligne_vannes.html#adaaab73d539c5e27287fd42b1f5ca64e", null ]
];