var searchData=
[
  ['openadc_0',['openAdc',['../sensor_8cpp.html#aaee06476c9ddb6ab8457694fdd20cccc',1,'openAdc(int adc):&#160;sensor.cpp'],['../sensor_8h.html#aaee06476c9ddb6ab8457694fdd20cccc',1,'openAdc(int adc):&#160;sensor.cpp']]],
  ['openfile_1',['openFile',['../classfile.html#a5eabb45d2518c4ad1391be6d5205cfdf',1,'file']]],
  ['opl_2',['opl',['../classopl.html#a43a83ace00cba207a89cf65e3b995d7e',1,'opl']]]
];
