var sensor_8cpp =
[
    [ "closeAdc", "sensor_8cpp.html#abf077aeb27cbf890c5006ed980d1c6f4", null ],
    [ "getAdc_value", "sensor_8cpp.html#a95ae932c940a8d52f42f256155300708", null ],
    [ "openAdc", "sensor_8cpp.html#aaee06476c9ddb6ab8457694fdd20cccc", null ],
    [ "readAdc", "sensor_8cpp.html#ab4df458eba25efa399c8531f2417d648", null ],
    [ "readChannels", "sensor_8cpp.html#a084710571b3a23b14fe1bc00ef626f52", null ],
    [ "ctx", "sensor_8cpp.html#abbcd977f5e414946647edf65cdeb74ce", null ],
    [ "fd", "sensor_8cpp.html#a274d2ff8aab7251a1c26c919ae3694f7", null ],
    [ "i", "sensor_8cpp.html#acb559820d9ca11295b4500f179ef6392", null ],
    [ "modbusReg", "sensor_8cpp.html#a00d425c5212b392df244df6c811bf1cd", null ],
    [ "num", "sensor_8cpp.html#a86cf672daa4e0ad11ad10efc894d19c8", null ],
    [ "rs485Connected", "sensor_8cpp.html#a598cc7808ae2f24d9e50a96acbffe018", null ],
    [ "tabSensorActivated", "sensor_8cpp.html#a63a90bdf4459f383b471c5b6ddca9f4e", null ],
    [ "valSensors", "sensor_8cpp.html#af1a8dcdbb54fb5c1b49459cde87d1e75", null ]
];