var sensor_8cpp =
[
    [ "closeAdc", "sensor_8cpp.html#abf077aeb27cbf890c5006ed980d1c6f4", null ],
    [ "getAdc_value", "sensor_8cpp.html#a95ae932c940a8d52f42f256155300708", null ],
    [ "openAdc", "sensor_8cpp.html#aaee06476c9ddb6ab8457694fdd20cccc", null ],
    [ "readAdc", "sensor_8cpp.html#ab4df458eba25efa399c8531f2417d648", null ],
    [ "readChannels", "sensor_8cpp.html#a084710571b3a23b14fe1bc00ef626f52", null ],
    [ "abort_read", "sensor_8cpp.html#a1f8a988f311c080db94c0185f9c81f77", null ],
    [ "adc", "sensor_8cpp.html#ae5d88649401f796b100a8ffb867b5507", null ],
    [ "fd", "sensor_8cpp.html#a274d2ff8aab7251a1c26c919ae3694f7", null ],
    [ "i", "sensor_8cpp.html#acb559820d9ca11295b4500f179ef6392", null ],
    [ "opt", "sensor_8cpp.html#a217e4b46670419e6c3665b3c9f96b7da", null ],
    [ "tabSensorActivated", "sensor_8cpp.html#a63a90bdf4459f383b471c5b6ddca9f4e", null ]
];