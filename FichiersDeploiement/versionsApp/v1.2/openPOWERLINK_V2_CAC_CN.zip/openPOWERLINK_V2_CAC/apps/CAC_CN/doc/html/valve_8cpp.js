var valve_8cpp =
[
    [ "getValvesInitValue", "valve_8cpp.html#ad4e5b817af0b9501d2a6e6deb0c89445", null ],
    [ "getValveValue", "valve_8cpp.html#a659d21ba354b3f756293314bf2c8dfc4", null ],
    [ "resetTimers", "valve_8cpp.html#ad6ff3dc82333091b53b2fbdc3ef5842e", null ],
    [ "setValvesValue", "valve_8cpp.html#add60b51091e6e3c9653ed8400895e3a1", null ],
    [ "beginTimer", "valve_8cpp.html#a7af143dbf44fa3c96fedf51b19e7b494", null ],
    [ "currentTime", "valve_8cpp.html#a718c1d403150a0052fdc750073ecede8", null ],
    [ "endTimer", "valve_8cpp.html#ab5efa5af4f5d074f434d5f7a433146af", null ],
    [ "offsets", "valve_8cpp.html#a268ac3b63f0fabe69c23e62ca83cfb70", null ],
    [ "timerStarted", "valve_8cpp.html#af18a1c02404999c7ccfe789b84c4a817", null ],
    [ "values", "valve_8cpp.html#a96860d8272d2d5ef1b46f17e271042da", null ]
];