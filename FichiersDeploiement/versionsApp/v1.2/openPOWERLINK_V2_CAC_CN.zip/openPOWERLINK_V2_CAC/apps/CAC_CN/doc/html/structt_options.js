var structt_options =
[
    [ "devName", "structt_options.html#a675c269016681a9bf07a16d975c20963", null ],
    [ "logCategory", "structt_options.html#ac2d0a48a3d2ed344da01233e48372775", null ],
    [ "logFormat", "structt_options.html#ad4dfda079fb51a7c23ff0321a2fc920e", null ],
    [ "logLevel", "structt_options.html#ac41ac397dd5398c735a7845a023e7877", null ],
    [ "nodeId", "structt_options.html#a1ddf0a10016825f0e7bae38a02387126", null ]
];