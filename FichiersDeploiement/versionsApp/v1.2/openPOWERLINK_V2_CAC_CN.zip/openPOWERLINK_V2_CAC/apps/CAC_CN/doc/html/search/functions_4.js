var searchData=
[
  ['file_0',['file',['../classfile.html#a22090815b0614f552f2cb2cc8f170572',1,'file']]]
];
