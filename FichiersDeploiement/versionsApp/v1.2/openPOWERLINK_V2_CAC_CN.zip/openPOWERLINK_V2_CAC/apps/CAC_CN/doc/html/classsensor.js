var classsensor =
[
    [ "sensor", "classsensor.html#aeaa38c2a2b5e33314a4fe9ff905dc0c6", null ],
    [ "~sensor", "classsensor.html#a9252346748c0bd090109ee5bcf45f13a", null ],
    [ "extinctSensor", "classsensor.html#ad3b9b11298007378ec5b9127694580af", null ],
    [ "initSensor", "classsensor.html#a136fdef7c492900f3ff9baa211607cb5", null ]
];