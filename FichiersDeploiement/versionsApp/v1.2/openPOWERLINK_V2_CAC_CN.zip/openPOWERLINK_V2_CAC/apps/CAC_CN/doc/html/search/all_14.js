var searchData=
[
  ['year_5fmonth_5fday_0',['year_month_day',['../classfile.html#a3bca228e2cfb8cd254e4770f8d1f058b',1,'file']]]
];
