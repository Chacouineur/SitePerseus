var searchData=
[
  ['statedef_0',['stateDef',['../status_error_define_8h.html#a8a5ff9e57db5d201dadd5d4dcacafd50',1,'statusErrorDefine.h']]],
  ['statuserrdef_1',['statusErrDef',['../status_error_define_8h.html#adf0c44f8de9b8e78b0e56caacfa1ac94',1,'statusErrorDefine.h']]]
];
