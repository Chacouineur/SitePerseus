var searchData=
[
  ['dataactivation_0',['dataActivation',['../csv_8cpp.html#a6d01cb64bb5d3e9ccda826e7b892ae18',1,'dataActivation:&#160;csv.cpp'],['../csv_8h.html#a6d01cb64bb5d3e9ccda826e7b892ae18',1,'dataActivation:&#160;csv.cpp']]],
  ['dataeg_1',['dataEG',['../csv_8cpp.html#ac119725e56f891ac0af277ad61a9eaf4',1,'dataEG:&#160;csv.cpp'],['../csv_8h.html#ac119725e56f891ac0af277ad61a9eaf4',1,'dataEG:&#160;csv.cpp']]],
  ['datafile_2',['dataFile',['../classfile.html#a60c20221b3650d600b0e10c300a66faa',1,'file']]],
  ['devname_3',['devName',['../structt_options.html#a675c269016681a9bf07a16d975c20963',1,'tOptions']]]
];
