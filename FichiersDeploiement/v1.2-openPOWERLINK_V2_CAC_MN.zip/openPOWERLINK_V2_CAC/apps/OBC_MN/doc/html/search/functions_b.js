var searchData=
[
  ['setactivated_5fin_5fmn_0',['setActivated_In_MN',['../opl_8cpp.html#a49a4367dee21b29ba4289959d09bdbfc',1,'setActivated_In_MN():&#160;opl.cpp'],['../opl_8h.html#a49a4367dee21b29ba4289959d09bdbfc',1,'setActivated_In_MN():&#160;opl.cpp']]],
  ['seteg_1',['setEG',['../opl_8cpp.html#a70d6c24319699ddf386b7ed176641580',1,'setEG(int16_t EG):&#160;opl.cpp'],['../opl_8h.html#a70d6c24319699ddf386b7ed176641580',1,'setEG(int16_t EG):&#160;opl.cpp']]],
  ['setegtomanualmode_2',['setEGToManualMode',['../opl_8cpp.html#aa811a9aae2371f56969a0f49d2fb6a01',1,'setEGToManualMode():&#160;opl.cpp'],['../opl_8h.html#aa811a9aae2371f56969a0f49d2fb6a01',1,'setEGToManualMode():&#160;opl.cpp']]],
  ['setvalues_5fout_5fmn_3',['setValues_Out_MN',['../opl_8cpp.html#ab19dffb79a3af5e336923b27bd441780',1,'setValues_Out_MN(int ligne, int16_t valeur):&#160;opl.cpp'],['../opl_8h.html#ab19dffb79a3af5e336923b27bd441780',1,'setValues_Out_MN(int ligne, int16_t valeur):&#160;opl.cpp']]],
  ['shutdownoplimage_4',['shutdownOplImage',['../opl_8cpp.html#a85847c888fe35030de14eb5c3190336c',1,'shutdownOplImage():&#160;opl.cpp'],['../opl_8h.html#aaf99cd726620ac95ff0d54f65485fb2a',1,'shutdownOplImage(void):&#160;opl.cpp']]],
  ['shutdownpowerlink_5',['shutdownPowerlink',['../opl_8cpp.html#aaf3f45fd8772392506e2cd143b46a455',1,'shutdownPowerlink(void):&#160;opl.cpp'],['../opl_8h.html#aaf3f45fd8772392506e2cd143b46a455',1,'shutdownPowerlink(void):&#160;opl.cpp']]]
];
