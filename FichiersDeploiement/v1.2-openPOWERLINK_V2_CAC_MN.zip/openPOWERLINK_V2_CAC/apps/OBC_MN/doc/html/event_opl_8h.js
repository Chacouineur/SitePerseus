var event_opl_8h =
[
    [ "tEventConfig", "structt_event_config.html", "structt_event_config" ],
    [ "initEvents", "event_opl_8h.html#a708072d52104add21873311bb5ad111a", null ],
    [ "processEvents", "event_opl_8h.html#ad6f574bee28d3a8f66b5885f365a8df2", null ]
];