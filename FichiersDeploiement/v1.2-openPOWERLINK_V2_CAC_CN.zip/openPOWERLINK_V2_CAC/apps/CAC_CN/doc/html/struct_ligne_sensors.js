var struct_ligne_sensors =
[
    [ "etatInitial", "struct_ligne_sensors.html#ac9c86088dd1113febf304c9da01a3cb3", null ],
    [ "maxValue", "struct_ligne_sensors.html#a118149e0588323c79b8519d7a167f948", null ],
    [ "minValue", "struct_ligne_sensors.html#afd60eeb6d4029750e659fc029b261171", null ]
];