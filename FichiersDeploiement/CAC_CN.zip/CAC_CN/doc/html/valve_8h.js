var valve_8h =
[
    [ "valve", "classvalve.html", "classvalve" ],
    [ "getValvesInitValue", "valve_8h.html#ad4e5b817af0b9501d2a6e6deb0c89445", null ],
    [ "getValveValue", "valve_8h.html#acd6fee6c4a2ab256a33ff4bc2c6ef745", null ],
    [ "resetTimers", "valve_8h.html#ad6ff3dc82333091b53b2fbdc3ef5842e", null ],
    [ "setValvesValue", "valve_8h.html#add60b51091e6e3c9653ed8400895e3a1", null ]
];