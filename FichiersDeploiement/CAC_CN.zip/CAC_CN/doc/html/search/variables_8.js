var searchData=
[
  ['logcategory_0',['logCategory',['../structt_options.html#ac2d0a48a3d2ed344da01233e48372775',1,'tOptions']]],
  ['logformat_1',['logFormat',['../structt_options.html#ad4dfda079fb51a7c23ff0321a2fc920e',1,'tOptions']]],
  ['loglevel_2',['logLevel',['../structt_options.html#ac41ac397dd5398c735a7845a023e7877',1,'tOptions']]]
];
