var searchData=
[
  ['fd_0',['fd',['../sensor_8cpp.html#a274d2ff8aab7251a1c26c919ae3694f7',1,'sensor.cpp']]],
  ['fgsoff_5fl_1',['fGsOff_l',['../opl_8h.html#a8f25e48b0b5122c1580e0728bcba0244',1,'opl.h']]]
];
