var event_opl_8h =
[
    [ "initEvents", "event_opl_8h.html#aa6211577a11055a43fb577b465ade606", null ],
    [ "processEvents", "event_opl_8h.html#ad6f574bee28d3a8f66b5885f365a8df2", null ]
];