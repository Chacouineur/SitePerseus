var sensor_8h =
[
    [ "sensor", "classsensor.html", "classsensor" ],
    [ "closeAdc", "sensor_8h.html#abf077aeb27cbf890c5006ed980d1c6f4", null ],
    [ "getAdc_value", "sensor_8h.html#a95ae932c940a8d52f42f256155300708", null ],
    [ "openAdc", "sensor_8h.html#aaee06476c9ddb6ab8457694fdd20cccc", null ],
    [ "readAdc", "sensor_8h.html#ab4df458eba25efa399c8531f2417d648", null ],
    [ "readChannels", "sensor_8h.html#a084710571b3a23b14fe1bc00ef626f52", null ],
    [ "valSensors", "sensor_8h.html#af1a8dcdbb54fb5c1b49459cde87d1e75", null ]
];