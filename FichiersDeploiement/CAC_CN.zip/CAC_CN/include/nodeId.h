#define NODEID 1
#define NB_NODES 3